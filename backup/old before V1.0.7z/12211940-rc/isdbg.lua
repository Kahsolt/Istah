#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- Istah Debugger
-- Name: isdbg
-- Author: Kahsolt
-- Time: 2016-12-13
-- Version: 1.2
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

require 'isparse'

local function help()
	print('The Istah Debugger')
	print('Usage:')
	print('\tIslex Test:\tisdbg l <filename>')
	print('\tIsparse Test:\tisdbg p <filename> [-nogc]')
	os.exit()
end

-----------
-- Entry --
-----------
if #arg < 2 then
	help()
elseif arg[1] == 'l' then
	islex.test(arg[2])
elseif arg[1] == 'p' then
	if arg[2] then
		Istah_Mode('Debug_NO_GC')
	else
		Istah_Mode('Debug')
	end
	isparse.test(arg[2])
end
