#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- Istah Namespace & Entity module
-- Name: isname
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.3
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
isname = {}			-- 模块名
local _M = isname		-- 临时模块名
dofile('isenv.lua')	-- 执行全局参数设定

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
-- Status Var
local MAX_LEN = 0

-- Tools
local newRef
local function newName(name)
	if Namespace[name] then
		return Namespace[name].ref
	else
		Namespace[name]={}
		newRef(name,0)					-- 0 = NIL
		if name:sub(1,1)=='$' then
			Namespace[name].type='FUNC'
		else
			Namespace[name].type='VESL'
		end
		return true
	end
end
local function newEntity(type, value)
	local _idx = 1		-- start from 1
	while EntitySet[_idx] do _idx=_idx+1 end	-- get a availabe index
	if _idx > MAX_LEN then MAX_LEN = _idx end	-- renew the top boundary
	EntitySet[_idx]={}
	EntitySet[_idx].type=type
	EntitySet[_idx].value=value
	EntitySet[_idx].chain=0
	return _idx
end
function newRef(name, ref)		-- ref==0 refers to the special NIL
	if not Namespace[name] then
		return false
	else
		if Namespace[name].ref then
			EntitySet[Namespace[name].ref].chain=EntitySet[Namespace[name].ref].chain-1
		end
		Namespace[name].ref=ref
		EntitySet[ref].chain=EntitySet[ref].chain+1
		return true
	end
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
-- Operators
function _M.init()
	MAX_LEN=0		-- the most high index used in EntitySet
	Namespace={}	-- Name -> ref, type
					-- {['var']={ref=1,type='VESL'},['$func']={ref=32, type='FUNC'}}
	EntitySet={}	-- Index  -> value, type, chain
					-- {['1']={type='STR', value=10086, chain=2}}
	EntitySet[0]={value=nil, type='ANY', chain=0}	-- default special value
end
function _M.existName(name)
	return Namespace[name]
end
function _M.linkNE(name, value)
	newName(name)
	local _idx
	if tonumber(value) then
		_idx=newEntity('NUM', tonumber(value))
	else
		_idx=newEntity('STR', value)
	end
	newRef(name, _idx)
end
function _M.aliasNN(name, name_copy)
	if not existName(name) then
		return false
	end
	newName(name_copy)
	newRef(name_copy,Namespace[name].ref)
	return true
end
function _M.delName(name)
	if Namespace[name] then
		EntitySet[Namespace[name].ref].chain=EntitySet[Namespace[name].ref].chain-1
		Namespace[name]=nil
	else
		err('Name "'..name..'" is NUL')
		return false
	end
end
function _M.getNameType(name)
	return Namespace[name] and Namespace[name].type 
end
function _M.getNameRef(name)
	return Namespace[name] and Namespace[name].ref 
end
function _M.getEntityType(name)
	return Namespace[name] and Namespace[name].ref and EntitySet[Namespace[name].ref].type or nil
end
function _M.getEntityValue(name)
	return Namespace[name] and Namespace[name].ref and EntitySet[Namespace[name].ref].value or nil
end
function _M.getEntityChain(name)
	return Namespace[name] and Namespace[name].ref and EntitySet[Namespace[name].ref].chain or nil
end
function _M.dbg(name)
	if name and Namespace[name] then
		print('['..name..']\ttype: '..Namespace[name].type..'\tref: '..Namespace[name].ref)
		if Namespace[name].ref~=0 then
			print('ref->\ttype: '..EntitySet[Namespace[name].ref].type..'\tchain: '..EntitySet[Namespace[name].ref].chain..'\tvalue: '..(EntitySet[Namespace[name].ref].value or ''))
		else
			print('ref->\tNIL')
		end
	else
		print('[Namespace]')
		print('name\ttype\tref')
		for k,v in pairs(Namespace) do
			print(k..'\t'..v.type..'\t'..v.ref)
		end
		print('<EntitySet>')
		print('ID\ttype\tchain\tvalue')
		for i=0,MAX_LEN do
			if EntitySet[i] then
				print(i..'\t'..EntitySet[i].type..'\t'..EntitySet[i].chain..'\t'..(EntitySet[i].value or ''))
			end
		end
	end
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.test()
	print('===============')
	print('Namespace Table')
	print('===============')
	_M.dbg()
end

-----------------------------------------------------------------------------
return _M
