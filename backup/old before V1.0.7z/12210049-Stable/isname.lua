#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- Istah Namespace & Entity module
-- Name: isname
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.3
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
isname = {}			-- 模块名
local _M = isname		-- 临时模块名
dofile('isenv.lua')	-- 执行全局参数设定

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
-- Status Var
local MAX_LEN = 0

-- Tools
local function setRef(name, ref)		-- ref==0 refers to the special NIL
	if not Namespace[name] then
		Namespace[name]=0
		EntitySet[0].chain=EntitySet[0].chain+1
	else
		EntitySet[Namespace[name]].chain=EntitySet[Namespace[name]].chain-1	-- break old link
		Namespace[name]=ref
		EntitySet[ref].chain=EntitySet[ref].chain+1	-- create new link
		return true
	end
end
local function setName(name)		-- RET: ref
	if Namespace[name] then
		return Namespace[name]
	else
		setRef(name,0)				-- 0 = NIL
		return Namespace[name]
	end
end
local function setEntity(value)		-- RET: index
	local _idx = 1		-- try from 1
	while EntitySet[_idx] do _idx=_idx+1 end	-- get a availabe index
	if _idx > MAX_LEN then MAX_LEN = _idx end	-- renew the top boundary
	EntitySet[_idx]={}
	EntitySet[_idx].value=value
	EntitySet[_idx].chain=0
	return _idx
end

local function err(level,msg)
	iserr.what('Isname',msg,level)
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
-- Operators
function _M.init()
	MAX_LEN=0		-- the most high index used in EntitySet
	Namespace={}	-- Name -> ref, type
					-- {['var']=1,['$func']=32}
	EntitySet={}	-- Index  -> value, type, chain
					-- {['1']={value=10086, chain=2}}
	EntitySet[0]={value=nil, chain=0}	-- default special value
end
function _M.existName(name)
	return Namespace[name]
end
function _M.linkNameEntity(name, value)
	if not value then				-- set to NIL
		setName(name)
		setRef(name, 0)
	else							-- set to new Entity
		setName(name)
		local _idx
		if tonumber(value) then
			_idx=setEntity(tonumber(value))
		else
			_idx=setEntity(value)
		end
		setRef(name, _idx)
	end
	return true
end
function _M.aliasName(name_src, name_dst)
	if not Namespace[name_src] then
		err(1,'Name "'..name_src..'" is NUL')
		return false
	end
	setName(name_dst)
	setRef(name_dst,Namespace[name_src])
	return true
end
function _M.delName(name)
	if Namespace[name] then
		EntitySet[Namespace[name]].chain=EntitySet[Namespace[name]].chain-1
		Namespace[name]=nil
	else
		err(1,'Name "'..name..'" is NUL')
		return false
	end
end
function _M.getNameRef(name)
	return Namespace[name]
end
function _M.getNameType(name)
	if not Namespace[name] then return nil end
	if name:sub(1,1)=='$' then
		return 'FUNC'
	else
		return 'VESL'
	end
end
function _M.getEntityChain(name)
	return Namespace[name] and EntitySet[Namespace[name]].chain or nil
end
function _M.getEntityValue(name)
	return Namespace[name] and EntitySet[Namespace[name]].value or nil
end
function _M.getEntityType(name)
	if Namespace[name] and EntitySet[Namespace[name]].value then
		if type(EntitySet[Namespace[name]].value)=='number' then
			return 'NUM'
		else
			return 'STR'
		end
	else
		return nil
	end
end
function _M.dbg(name)
	if name and Namespace[name] then
		print('['..name..']\tref: '..Namespace[name])
		if Namespace[name]~=0 then
			print('ref->\tchain: '..EntitySet[Namespace[name]].chain..'\ttype: '..(tostring(type(EntitySet[Namespace[name]].value)) or '')..'\tvalue: '..(EntitySet[Namespace[name]].value or ''))
		else
			print('ref->\tNIL')
		end
	else
		print('[Namespace]')
		print('name\tref')
		for k,v in pairs(Namespace) do
			print(k..'\t'..v)
		end
		print('<EntitySet>')
		print('ID\tchain\ttype\tvalue')
		for i=0,MAX_LEN do
			if EntitySet[i] then
				print(i..'\t'..EntitySet[i].chain..'\t'..(tostring(type(EntitySet[i].value)) or '')..'\t'..(EntitySet[i].value or ''))
			end
		end
	end
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.test()
	_M.dbg()
end

-----------------------------------------------------------------------------
return _M
