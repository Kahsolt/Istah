#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- Istah Parser Module
-- Name: isparse
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.1
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
isparse = {}		-- 模块名
local _M = isparse	-- 临时模块名
dofile('isenv.lua')	-- 引入模块
require 'islex'
require 'isname'
require 'isgc'
require 'iserr'

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
-- Tools
local function testToken(type)		-- test only
	return Token.type==TokenType[type]
end
local function absorbToken(type)	-- test, if match then get next token
	if Token.type==TokenType[type] then
		islex.nextToken()
		return true
	else
		return false
	end
end
local function getToken()	-- get VESL, FUNC, NUM ,STR
	t=Token.value			-- get name of VESL|FUNC or value of NUM|STR
	islex.nextToken()
	return t
end
local function err(id)
	iserr.what('Isparse',id)
end

-- Local Debug
local function dbg(func)
	print('[Func] '..func..'\t[Token] '..(Token.type or '<NK>')..'\t'..(Token.value or '<Symbol>'))
end

-- Parsers
local parseExecutionBlock, parseStatement, parseControl, parseData
function parseExecutionBlock()		-- <执行块>	::=	{<语句>|<控制>}
	dbg('EB')
	while testToken('VESL') or testToken('FUNC') or testToken('RET') or testToken('DBG') or testToken('INPUT') or testToken('OUTPUT') or testToken('LAGBR') or testToken('LSQBR') do
		if testToken('VESL') or testToken('FUNC') or testToken('RET') or testToken('DBG') or testToken('INPUT') or testToken('OUTPUT') then
			parseStatement()
		elseif testToken('LAGBR') or testToken('LSQBR') then
			parseControl()
		end
	end
end
function parseStatement()			-- <语句>	::=	<容器处理>|<函数处理>|<退返句>|<调试句>|<输入句>|<输出句>
	dbg('S')
	local parseStatementHandleVessel, parseStatementHandleFunction, parseStatementReturn, parseStatementDebug, parseStatementInput, parseStatementOutput
	function parseStatementHandleVessel()	-- <容器处理>	::=	<容器名>'='(<数符式>|(<函数名>'{'[<数符式>{','<数符式>}]'}'))|<容器名>'&='<容器名>
		dbg('SHV')
		-- local _vesl=getToken()
		if absorbToken('LINK') then
			os.exit()
		end
		os.exit()
	end
	function parseStatementHandleFunction()	-- <函数处理>::=<函数名>'=''{'[<容器名>{','<容器名>}]'|'<执行块>'}'|<函数名>'{'[<数符式>{','<数符式>}]'}'|<函数名>'&='<函数名>
		dbg('SHF')
		-- local _func=getToken()
	end
	function parseStatementReturn()			-- <退返句>::='=>'<数符式>
		dbg('SR')
		absorbToken('RET')
	end
	function parseStatementDebug()			-- <调试句>::='@'[('*'|<容器名>|<函数名>)]
		dbg('SD')
		absorbToken('DBG')
		if absorbToken('MUL') then
			isname.dbg()
		elseif testToken('VESL') or testToken('FUNC') then
			local _name = getToken()
			isname.dbg(_name)
		end
	end
	function parseStatementInput()			-- <输入句>::='<<'<容器名>
		dbg('SI')
		absorbToken('INPUT')
		local _vesl=getToken()
		local _value=io.read('*l')	-- read a line
		isname.linkNE(_vesl,_value)
	end
	function parseStatementOutput()			--<输出句>::=	'>>'<数符式>
		dbg('SO')
		absorbToken('OUTPUT')
		print(tostring(parseData()) or '')
	end

	if testToken('VESL') then parseStatementHandleVessel()
	elseif testToken('FUNC') then parseStatementHandleFunction()
	elseif testToken('RET') then parseStatementReturn()
	elseif testToken('DBG') then parseStatementDebug()
	elseif testToken('INPUT') then parseStatementInput()
	elseif testToken('OUTPUT') then parseStatementOutput()
	else err('Bad Statement Head') end
end
function parseControl()						-- <控制>::=<分支结构>|<循环结构>
	dbg('C')
	local parseControlBranch, parseControlLoop
	local parseControlLogicExpression, parseControlLogicFactor
	function parseControlLogicExpression()		-- <逻辑式>::='!'<逻辑式>|<逻辑子>[('&&'|'||')<逻辑子>]|'('<逻辑式>')'
		dbg('CLE')
		if testToken('NOT') then
			local _logexp = parseControlLogicExpression()
			return (_logexp~=nil and (not _logexp))) or nil
		elseif testToken('NUM') or testToken('STR') then
			local _l = parseControlLogicFactor()
			if testToken('AND') or testToken('OR') then
				local _op
				if absorbToken('AND') then _op = 'AND'
				elseif absorbToken('OR') then _op='OR'
				else err('Uncoginzed Logic Operator') end
				local _r = parseControlLogicFactor()
				if _op == 'AND' then
					return ((_l~=nil) and (_r~=nil) and (_l and _r)) or nil
				else
					return ((_l~=nil) and (_r~=nil) and (_l or _r)) or nil
				end
			else
				return (_l~=nil and _l) or nil
			end
		elseif absorbToken('LRDBR') then
			local _logexp = parseControlLogicExpression()
			absorbToken('RRDBR')
			return _logexp
		else
			return nil
		end
	end
	function parseControlLogicFactor()			-- <逻辑子>::='*'|'!'|<数>('=='|'!='|'>='|'<='|'>'|'<')<数>|<字串>('=='|'!='|'>='|'<='|'>'|'<')<字串>|<容器>('=='|'!='|'>='|'<='|'>'|'<')<容器>
		dbg('CLF')
		if testToken('MUL') or testToken('NOT') then
			if absorbToken('MUL') then return true
			elseif absorbToken('NOT') then retsurn false
			end
		elseif testToken('NUM') or testToken('STR') or testToken('VESL') then
			local _l, _l_type
			if testToken('NUM') then
				_l = getToken()
				_l_type='NUM'
			elseif testToken('STR') then
				_l = getToken()
				_l_type='STR'
			else
				local _vesl = getToken()
				if not isname.getEntityType(_vesl) then
					err('the VESL is NUL')
				else
					_l = isname.getEntityValue(_vesl)
					_l_type = isname.getEntityType(_vesl)
				end
			end
			local _op
			if testToken('EQU') or testToken('NEQ') or testToken('ELT') or testToken('EGT') or testToken('LES') or testToken('GRT') then
				if absorbToken('EQU') then _op='EQU'
				elseif absorbToken('NEQ') then _op='NEQ'
				elseif absorbToken('ELT') then _op='ELT'
				elseif absorbToken('EGT') then _op='EGT'
				elseif absorbToken('LES') then _op='LES'
				elseif absorbToken('GRT') then _op='GRT'
				end
				if testToken('NUM') or testToken('STR') or testToken('VESL') then
					local _r, _r_type
					if testToken('NUM') then
						_r = getToken()
						_r_type='NUM'
					elseif testToken('STR') then
						_r = getToken()
						_r_type='STR'
					else
						local _vesl = getToken()
						if not isname.getEntityType(_vesl) then
							err('the VESL is NUL')
						else
							_r = isname.getEntityValue(_vesl)
							_r_type = isname.getEntityType(_vesl)
						end
					end
					if _l_type~=_r_type then
						return false
					else
						if _op=='EQU' then return _l and _r and (_l == _r)
						elseif _op=='NEQ' then return _l and _r and (_l ~= _r)
						elseif _op=='ELT' then return _l and _r and (_l <= _r)
						elseif _op=='EGT' then return _l and _r and (_l >= _r)
						elseif _op=='LES' then return _l and _r and (_l < _r)
						elseif _op=='GRT' then return _l and _r and (_l > _r)
					end
				end
			else err('Bad Compare Operator') end
		else
			err('Bad Logic Factor')
		end
	end
	function parseControlBranch()			-- <分支结构>::='<'<逻辑式>'?'<执行块>{'|'<逻辑式>'?'<执行块>}'>'
		dbg('CB')
		absorbToken('LAGBR')
		local _logexp=parseControlLogicExpression()
		absorbToken('QUERY')
		if _logexp==true then
			parseExecutionBlock()
		else
			while not testToken('SEGMT') and not testToken('RAGBR') do nextToken() end
		end
		while absorbToken('SEGMT') do
			_logexp=parseControlLogicExpression()
			if _logexp==true then
				parseExecutionBlock()
			else
				while not testToken('SEGMT') and not testToken('RAGBR') do nextToken() end
			end
		end
		absorbToken('RAGBR')
	end
	function parseControlLoop()				-- <循环结构>::='['<逻辑式>'?'<执行块>']'|'['<执行块>'|'<逻辑式>']'
		dbg('CL')
		absorbToken('LSQBR')
	end

	if testToken('LAGBR') then parseStatementHandleVessel()
	elseif testToken('LSQBR') then parseStatementHandleFunction()
	end
end
function parseData()						-- <数据>::=<代数式>|<字串式>
	dbg('D')
	local parseDataAlgebraExpression, parseDataAlgebraMidware, parseDataAlgebraFactor
	local parseDataStringExpression, parseDataStringFactor
	function parseDataAlgebraExpression()		-- <代数式>::=['+'|'-']<代数件>{('+'|'-')<代数件>}
		dbg('DAE')
		local _sign = 1
		if absorbToken('SUB') then _sign = -1
		else absorbToken('ADD') end
		local _a = parseDataAlgebraMidware()
		if testToken('ADD') or testToken('SUB') then
			local _op
			if absorbToken('ADD') then _op='ADD'
			elseif absorbToken('SUB') then _op='SUB'
			else err('Uncoginzed Algbra Operator') end
			local _b = parseDataAlgebraMidware()
			-- print('ADDSUB: _a='..(_a or '<BAD>')..'\t_b='..(_b or '<BAD>'))	-- inner dbg
			if _op=='ADD' then
				return (_a and _b and _sign*_a+_b) or nil
			else
				return (_a and _b and _sign*_a-_b) or nil
			end
		else
			return (_a and _sign*_a) or nil
		end
	end
	function parseDataAlgebraMidware()			-- <代数件>::=<代数子>{('*'|'/'|'%')<代数子>}
		dbg('DAM')
		local _x = parseDataAlgebraFactor()
		if testToken('MUL') or testToken('DIV') or testToken('MOD') then
			local _op
			if absorbToken('MUL') then _op='MUL'
			elseif absorbToken('DIV') then _op='DIV'
			elseif absorbToken('MOD') then _op='MOD'
			else err('Uncoginzed Algbra Operator') end
			local _y = parseDataAlgebraFactor()
			-- print('MULDIV: _x='..(_x or '<BAD>')..'\t_y='..(_y or '<BAD>'))	-- inner dbg
			if _op=='MUL' then
				return (_x and _y and _x*_y) or nil
			elseif _op=='DIV' then
				return (_x and _y and _x/_y) or nil
			else
				return (_x and _y and _x%_y) or nil
			end
		else
			return (_x) or nil
		end
	end
	function parseDataAlgebraFactor()			-- <代数子>::=<容器名>|<数>|'('<代数子>')'
		dbg('DAF')
		if testToken('VESL') then
			local _vesl = getToken()
			if isname.getEntityType(_vesl) then
				err('the VESL is NUL')
			end
			local _value = tonumber(isname.getEntityValue(_vesl))
			if _value then
				return _value
			else
				err('Entity cannot be converted to a number')
			end
		elseif testToken('NUM') then
			return tonumber(getToken())
		elseif absorbToken('LRDBR') then
			local _factor = parseDataAlgebraFactor()
			absorbToken('RRDBR')
			return _factor
		else
			return nil
		end
	end
	function parseDataStringExpression()		-- <符串式>::=<符串子>{'..'<符串子>}
		dbg('DSE')
		local _str=parseDataStringFactor()
		while absorbToken('CONCAT') do
			local _seg=parseDataStringFactor()
			_str=_str..(_seg or '')
		end
		return _str
	end
	function parseDataStringFactor()			-- <符串子>::=<容器名>|<符串>
		dbg('DSF')
		if testToken('STR') then
			return getToken()
		else
			return isname.getEntityValue(getToken())
		end
	end

	if testToken('ADD') or testToken('SUB') or testToken('LRDBR') or testToken('NUM') or (testToken('VESL') and isname.getEntityType(Token.value)=='NUM') then
		return parseDataAlgebraExpression()
	elseif testToken('STR') or (testToken('VESL') and isname.getEntityType(Token.value)=='STR') then
		return parseDataStringExpression()
	elseif (testToken('VESL') or testToken('FUNC')) and not isname.getNameRef(Token.value) then
		err('that Name is NUL')
	else
		err('Bad Data Segment Head')
	end
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init(fin)
	islex.init(fin)
	isname.init()
end
function _M.nextExecution()
	islex.nextToken()		-- Pre-read a token
	parseExecutionBlock()
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.test(fin)
	_M.init(fin)
	_M.nextExecution()
	isname.test()
end

-----------------------------------------------------------------------------
return _M
