#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- Istah Interpreter
-- Name: istah
-- Author: Kahsolt
-- Time: 2016-12-13
-- Version: 1.0
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

require 'isparse'

local function help()
	print('The Istah Language Interpreter by Kahsolt')
	print('Usage:')
	print('\tInteractive Mode:\tistah')
	print('\tFile Execution Mode:\tistah <filename>')
	os.exit()
end
--[[
if #arg==0 then
	--print('Enter interact mode')
elseif #arg==1 then
	--print('Enter FileExecution mode')
	islex.test(arg[1])
else
	help()
end
]]--

if #arg ~= 2 then
	print('istah.lua l|p <fpath>')
elseif arg[1] == 'l' then
	islex.test(arg[2])
elseif arg[1] == 'p' then
	isparse.test(arg[2])
end
