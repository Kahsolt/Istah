#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- Istah Configuration File
-- Name: iscfg
-- Author: Kahsolt
-- Time: 2016-12-21
-- Version: 1.1
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Boolean Setting
-----------------------------------------------------------------------------
-- switch of the gc module
ISTAH_GC	=	true

-- debug the treeing of the parsers
ISTAH_DBG	=	false
-- debug the data parsers
ISTAH_DBG_DATA	=	false
-- debug the control parsers
ISTAH_DBG_LOGIC	=	false

-----------------------------------------------------------------------------
-- String Setting
-----------------------------------------------------------------------------
ISTAH_FILEIN	=	'in.is'